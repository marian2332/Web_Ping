﻿namespace Kasy.Models
{
    public class Address
    {
        public string Nazwa { get; set; }
        public string Adres { get; set; }
        public string Ping { get; set; }
        public string Kolor { get; set; }
        

    }
}
